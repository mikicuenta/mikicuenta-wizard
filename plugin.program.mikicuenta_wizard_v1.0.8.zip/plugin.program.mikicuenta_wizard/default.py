import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import shutil
import zipfile
import urllib.request

addon = xbmcaddon.Addon()
dialog = xbmcgui.Dialog()

# Versión actual del wizard
CURRENT_WIZARD_VERSION = "1.1.3"

# Paths
home_path = xbmcvfs.translatePath("special://home/")
zip_path = os.path.join(home_path, "build.zip")
addons_path = os.path.join(home_path, "addons")
userdata_path = os.path.join(home_path, "userdata")

# ───────────────
# Funciones auxiliares
# ───────────────
def download_file(url, dest):
    try:
        dp = xbmcgui.DialogProgress()
        dp.create("MikiCuenta Wizard", "Descargando...")

        with urllib.request.urlopen(url) as response:
            total_size = int(response.getheader("Content-Length").strip())
            downloaded = 0
            block_size = 1024 * 1024

            with open(dest, "wb") as out_file:
                while True:
                    buffer = response.read(block_size)
                    if not buffer:
                        break
                    out_file.write(buffer)
                    downloaded += len(buffer)

                    percent = int(downloaded * 100 / total_size)
                    dp.update(percent, f"Descargando... {percent}%")

                    if dp.iscanceled():
                        dp.close()
                        os.remove(dest)
                        dialog.ok("MikiCuenta Wizard", "❌ Descarga cancelada.")
                        return False

        dp.close()
        return True
    except Exception as e:
        dialog.ok("Error", f"No se pudo descargar:\n{str(e)}")
        return False

# ───────────────
# Funciones principales
# ───────────────
def borrar_cache():
    cache_path = xbmcvfs.translatePath("special://home/cache/")
    shutil.rmtree(cache_path, ignore_errors=True)
    os.makedirs(cache_path, exist_ok=True)
    dialog.ok("Kodi MikiCuenta", "✅ Caché borrada correctamente.")

def instalar_build():
    builds = [
        {"nombre": "MikiCuentaBuild_AeonNox", "url": "https://www.dropbox.com/scl/fi/hw84oodvy9mpmthwtd2pd/MikiCuentaBuild_AeonNoxsilvo.zip?rlkey=hx82jxhg79hvwp95uifijdxqv&st=ll8z5fs7&dl=1"},
        {"nombre": "MikiCuentaKodi_Simple", "url": "https://www.dropbox.com/scl/fi/26p5zhxsfilb99f2zx1oy/MikiCuentaKodi_Simple.zip?rlkey=qqm0giialax2wzjf29658lcc1&st=ft2zbt6z&dl=1"}
    ]

    opciones = [b["nombre"] for b in builds] + ["❌ Cancelar"]
    seleccion = dialog.select("Selecciona la build a instalar", opciones)

    if seleccion == -1 or seleccion == len(opciones) - 1:
        return

    build_url = builds[seleccion]["url"]

    if dialog.yesno("MikiCuenta Wizard", f"Se instalará:\n{builds[seleccion]['nombre']}\n\nEsto borrará tu configuración actual.\n¿Quieres continuar?"):
        try:
            if not download_file(build_url, zip_path):
                return

            if not zipfile.is_zipfile(zip_path):
                dialog.ok("Error", "❌ El archivo no es un ZIP válido.")
                return

            shutil.rmtree(addons_path, ignore_errors=True)
            shutil.rmtree(userdata_path, ignore_errors=True)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                files = zip_ref.infolist()
                total_files = len(files)

                dp = xbmcgui.DialogProgress()
                dp.create("MikiCuenta Wizard", "Instalando...")

                for count, file in enumerate(files, 1):
                    zip_ref.extract(file, home_path)
                    percent = int(count * 100 / total_files)
                    dp.update(percent, f"Instalando... {percent}%")

                    if dp.iscanceled():
                        dp.close()
                        dialog.ok("MikiCuenta Wizard", "❌ Instalación cancelada.")
                        return

                dp.close()

            os.remove(zip_path)
            dialog.ok("MikiCuenta Wizard", f"✅ {builds[seleccion]['nombre']} instalada.\nKodi se cerrará ahora.")
            xbmc.executebuiltin('Quit()')
        except Exception as e:
            dialog.ok("Error", f"Falló la instalación:\n{str(e)}")

def check_updates():
    try:
        url = "https://TU-SERVIDOR/version.txt"
        response = urllib.request.urlopen(url)
        data = response.read().decode("utf-8").splitlines()
        info = dict(line.split("=", 1) for line in data if "=" in line)

        if "wizard" in info and info["wizard"] != CURRENT_WIZARD_VERSION:
            dialog.ok("Actualización de Wizard",
                      f"Tienes {CURRENT_WIZARD_VERSION}, disponible {info['wizard']}.\n\nActualiza desde el repositorio.")

        builds = {
            "MikiCuentaBuild_AeonNox": {"current": "1.0.2", "remote": info.get("build_completa"), "url": "https://TU-LINK/build_completa.zip"},
            "MikiCuentaKodi_Simple": {"current": "1.0.0", "remote": info.get("build_simple"), "url": "https://TU-LINK/build_simple.zip"}
        }

        for build_name, build_data in builds.items():
            if build_data["remote"] and build_data["remote"] != build_data["current"]:
                if dialog.yesno("Actualización de Build",
                                f"Hay nueva versión de {build_name} ({build_data['remote']}).\n¿Instalar ahora?"):
                    if download_file(build_data["url"], zip_path):
                        dialog.ok("Actualización", f"✅ {build_name} actualizado.")

        if "mensaje" in info:
            dialog.ok("Novedades", info["mensaje"])

    except Exception as e:
        dialog.ok("Error", f"No se pudo comprobar actualizaciones:\n{str(e)}")

def limpieza_avanzada():
    paths = [
        xbmcvfs.translatePath("special://home/cache/"),
        xbmcvfs.translatePath("special://home/userdata/Thumbnails/"),
        xbmcvfs.translatePath("special://home/addons/packages/")
    ]
    for p in paths:
        shutil.rmtree(p, ignore_errors=True)
        os.makedirs(p, exist_ok=True)
    dialog.ok("Limpieza avanzada", "✅ Caché, Thumbnails y Packages borrados.")

def configurar_fuentes():
    sources_file = xbmcvfs.translatePath("special://userdata/sources.xml")
    xml = '''<sources>
    <files>
        <source>
            <name>MikiCuenta Repo</name>
            <path pathversion="1">https://TU-SERVIDOR/repo/</path>
        </source>
        <source>
            <name>Kodi Oficial</name>
            <path pathversion="1">https://mirrors.kodi.tv/addons/</path>
        </source>
        <source>
            <name>Dregs</name>
            <path pathversion="1">https://dregs1.github.io/</path>
        </source>
        <source>
            <name>Acestream Channel</name>
            <path pathversion="1">https://gunter257.github.io/repoachannels/</path>
        </source>
        <source>
            <name>Balandro</name>
            <path pathversion="1">https://repobal.github.io/base</path>
        </source>
        <source>
            <name>Konectas</name>
            <path pathversion="1">https://konectas.github.io</path>
        </source>
        <source>
            <name>Horus</name>
            <path pathversion="1">https://mandrakodi.github.io/</path>
        </source>
        <source>
            <name>Jellyfin</name>
            <path pathversion="1">https://github.com/awesome-jellyfin/awesome-jellyfin</path>
        </source>
        <source>
            <name>EzMaintenance</name>
            <path pathversion="1">https://peno64.github.io/repository.peno64</path>
        </source>
        <source>
            <name>Alfa</name>
            <path pathversion="1">https://alfa-addon.com/alfa/</path>
        </source>
        <source>
            <name>Diggz</name>
            <path pathversion="1">https://tinyurl.com/diggz123</path>
        </source>
        <source>
            <name>Greenball</name>
            <path pathversion="1">https://ajsm90.github.io/greenball.repo</path>
        </source>
        <source>
            <name>Blackghost</name>
            <path pathversion="1">https://bluegray25.github.io/</path>
        </source>
        <source>
            <name>Michaz</name>
            <path pathversion="1">https://michaz1988.github.io/repo/</path>
        </source>
      
    </files>
</sources>'''
    with open(sources_file, "w", encoding="utf-8") as f:
        f.write(xml)
    dialog.ok("Fuentes configuradas", "✅ Se añadieron las fuentes principales de Kodi.\nReinicia Kodi para verlas.")

def descargar_apks():
    url = "https://www.dropbox.com/scl/fi/wvqnaip0tyaydppginq5l/APK.zip?rlkey=mf0wydyixtm8x3gmqsi8y6cjc&st=kpipjumf&dl=1"  # enlace directo al ZIP con tus APKs
    destino_zip = os.path.join(home_path, "apks.zip")
    destino_carpeta = os.path.join(home_path, "apks")

    if not download_file(url, destino_zip):
        return

    try:
        shutil.rmtree(destino_carpeta, ignore_errors=True)
        os.makedirs(destino_carpeta, exist_ok=True)

        with zipfile.ZipFile(destino_zip, 'r') as zip_ref:
            zip_ref.extractall(destino_carpeta)

        os.remove(destino_zip)

        dialog.ok(
            "Descarga completada",
            f"✅ APKs descargadas en:\n{destino_carpeta}\n\n"
            "Ahora abre esa carpeta desde tu gestor de archivos Android e instala la APK que quieras."
        )
    except Exception as e:
        dialog.ok("Error", f"No se pudo extraer las APKs:\n{str(e)}")

# ───────────────
# Mensaje de bienvenida
# ───────────────
dialog.ok(
    "✨ Bienvenido a MikiCuenta Wizard ✨",
    "Este asistente te ayudará a:\n\n"
    "✔ Instalar la Build oficial\n"
    "✔ Limpiar Kodi (básico y avanzado)\n"
    "✔ Revisar actualizaciones\n"
    "✔ Añadir fuentes\n"
    "✔ Descargar APKs\n\n"
    "Selecciona una opción en el menú."
)

# ───────────────
# Menú principal
# ───────────────
while True:
    opciones = [
        "──────────────",
        "[1] Instalar Build",
        "[2] Borrar caché",
        "[3] Actualizaciones",
        "[4] Limpieza avanzada",
        "[5] Añadir fuentes",
        "[6] Descargar APKs",
        "[7] Salir",
        "──────────────"
    ]
    seleccion = dialog.select("✨ MikiCuenta Wizard ✨", opciones)

    if seleccion == -1 or seleccion == 7:
        break
    elif seleccion == 1:
        instalar_build()
    elif seleccion == 2:
        borrar_cache()
    elif seleccion == 3:
        check_updates()
    elif seleccion == 4:
        limpieza_avanzada()
    elif seleccion == 5:
        configurar_fuentes()
    elif seleccion == 6:
        descargar_apks()
